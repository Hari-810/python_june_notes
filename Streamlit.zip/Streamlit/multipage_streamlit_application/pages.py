import streamlit as st

def home():
    st.title("Home Page")
    st.write("Welcome to the Home Page!")
    # Add content specific to the home page

def about():
    st.title("About Page")
    st.write("Welcome to the About Page!")
    # Add content specific to the about page

def contact():
    st.title("Contact Page")
    st.write("Welcome to the Contact Page!")
    # Add content specific to the contact page
